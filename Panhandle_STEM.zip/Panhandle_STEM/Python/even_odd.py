#/usr/bin/env python3

user_number = int(input('Enter a whole number: '))

while user_number % 2 == 0:
    print( user_number,  'is an even number')
    user_number = int(input('Enter another whole number: '))
#end while
print('You entered an odd number!')
