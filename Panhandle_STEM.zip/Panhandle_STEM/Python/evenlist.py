#!/usr/bin/python3

evenlist = []
usernum = int(input('Even number up to ?'))
for i in range(2, usernum+1, 2):
    evenlist.append(i)
#end for
print('Items in evenlist')
print(evenlist)
