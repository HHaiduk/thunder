#!/usr/bin/env python3

def relative_to_zero(num):
   if num > 0:
       print(num, "is greater than zero")
   elif num < 0:
       print(num, "is less than zero")
   else:
       print(num, "is zero")
    #end if
#end relative_to_zero

# main program starts here
answer = 'Y'

while answer in ['y', 'Y']:
    user_num = int(input("Please input an integer number "))

    relative_to_zero(user_num)

    answer = input("Do you wish to input another number? <y,Y> ")
#end while
